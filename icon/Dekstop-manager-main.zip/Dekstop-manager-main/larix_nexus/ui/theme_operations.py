# -*- coding: utf-8 -*-
"""Theme and UI styling operations for Larix Nexus."""

import os
from PySide6.QtCore import Qt, QSize, QObject
from PySide6.QtGui import QIcon, QColor, QPixmap, QPainter
from PySide6.QtWidgets import QSplitter, QAbstractButton, QApplication, QStyle
import PySide6.QtGui as QtGui
from ..constants import (
    THEME_LIGHT, THEME_DARK, TOOLBAR_REFRESH_ICON, TOOLBAR_UPLOAD_ICON,
    TOOLBAR_DOWNLOAD_ICON, TOOLBAR_NEW_FOLDER_ICON, TOOLBAR_SETTINGS_ICON,
    SORT_ICON_UP_PATH, SORT_ICON_DOWN_PATH, ARROW_LEFT_PATH, ARROW_RIGHT_PATH,
    FILTER_ICON_PATH, INSERT_ICON_PATH, REFRESH_ICON_PATH, BACK_ICON_PATH,
    SYNC_ICON_PATH, CUSTOM_PLUS_ICON_PATH, CUSTOM_SAVE_ICON_PATH, EDIT_ICON_PATH,
    COMPARISON_ICON_PATH, MOVE_FOLDER_ICON_PATH, COPY_FOLDER_ICON_PATH,
    DELETE_ICON_PATH, ALARM_ICON_PATH, NO_FOLDER_ICON_PATH, GEAR_ICON_NAME, CHOICE_ICON_PATH
)
from ..utils.theme import load_white_icon, white_tinted_icon, _tint_pixmap
from ..utils.i18n import t
from ..utils.paths import rsrc_path

# Define icon paths locally
ARROW_ICON_PATHS = {
    "up": SORT_ICON_UP_PATH,
    "down": SORT_ICON_DOWN_PATH,
    "left": ARROW_LEFT_PATH,
    "right": ARROW_RIGHT_PATH,
}


def _themed_icon(self, path: str, *, tint_allowed: bool = True) -> QIcon:
    """Return icon taking current theme into account."""
    try:
        if not path:
            return QIcon()
        normalized = path.replace("\\", "/")
        if normalized in ARROW_ICON_PATHS:
            if getattr(self, "_current_theme", THEME_LIGHT) == THEME_DARK:
                return load_white_icon(path)
            return QIcon(path)
        if getattr(self, "_current_theme", THEME_LIGHT) == THEME_DARK and tint_allowed:
            return load_white_icon(path)
        return QIcon(path)
    except Exception:
        return QIcon(path)


def _themed_standard_icon(self, std_icon: QStyle.StandardPixmap) -> QIcon:
    """Standard icon adjusted for current theme (white in dark)."""
    try:
        icon = self.style().standardIcon(std_icon)
    except Exception:
        icon = QIcon()
    if getattr(self, "_current_theme", THEME_LIGHT) == THEME_DARK:
        return white_tinted_icon(icon)
    return icon


def _update_filter_icon_pm(self) -> None:
    """(Re)load header filter overlay pixmap honoring current theme."""
    self._filter_icon_pm = None
    try:
        if not os.path.exists(FILTER_ICON_PATH):
            return

        target_size = QSize(14, 14)
        dark = getattr(self, "_current_theme", THEME_LIGHT) == THEME_DARK
        pm = QPixmap()

        if dark:
            try:
                icon = load_white_icon(FILTER_ICON_PATH)
                pm = icon.pixmap(target_size)
            except Exception:
                pm = QPixmap()

        if pm.isNull():
            pm = QPixmap(FILTER_ICON_PATH)
            if dark and not pm.isNull():
                pm = _tint_pixmap(pm, QColor(Qt.white))

        if pm.isNull():
            return

        if pm.size() != target_size:
            pm = pm.scaled(target_size, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        self._filter_icon_pm = pm
    except Exception:
        pass


def _update_search_icon(self) -> None:
    """Backward-compatible no-op after removing deep search button."""
    return


def _refresh_search_palette(self) -> None:
    """Refresh search input palette for dark/light theme."""
    if not hasattr(self, "edit_search"):
        return
    dark = getattr(self, "_current_theme", THEME_LIGHT) == THEME_DARK
    try:
        palette = self.edit_search.palette()
        if dark:
            palette.setColor(self.edit_search.backgroundRole(), QColor("#2D2D2D"))
            palette.setColor(self.edit_search.foregroundRole(), QColor("#FFFFFF"))
        else:
            palette.setColor(self.edit_search.backgroundRole(), QColor("#FFFFFF"))
            palette.setColor(self.edit_search.foregroundRole(), QColor("#000000"))
        self.edit_search.setPalette(palette)
    except Exception:
        pass


def _refresh_secondary_style(self, *buttons: QAbstractButton) -> None:
    """Refresh secondary button icons for current theme."""
    dark = getattr(self, "_current_theme", THEME_LIGHT) == THEME_DARK
    for btn in buttons:
        try:
            self._restore_button_icon_from_base(btn)
            if dark:
                self._apply_hover_filter(btn)
        except Exception:
            pass


def _apply_icon_theme(self, theme: str) -> None:
    """Apply icon theme to all relevant UI elements."""
    dark = theme == THEME_DARK
    
    def set_icon(btn: QAbstractButton, path: str, *, tint: bool = True, required: bool = False, text_on_missing: str | None = None):
        try:
            icon = self._themed_icon(path, tint_allowed=tint) if tint else QIcon(path)
            btn.setIcon(icon)
            if not icon.isNull():
                btn.setProperty("icon_path", path)
                return True
        except Exception:
            pass
        if required and text_on_missing:
            btn.setText(text_on_missing)
        return False
    
    try:
        for btn_name, icon_path in [
            ("btn_refresh", REFRESH_ICON_PATH),
            ("btn_upload", TOOLBAR_UPLOAD_ICON),
            ("btn_download", CUSTOM_SAVE_ICON_PATH),
            ("btn_new_folder", TOOLBAR_NEW_FOLDER_ICON),
            ("btn_columns", TOOLBAR_SETTINGS_ICON),
            ("btn_back", BACK_ICON_PATH),
            ("btn_sync_all", SYNC_ICON_PATH),
            ("btn_plus", CUSTOM_PLUS_ICON_PATH),
            ("btn_rename", EDIT_ICON_PATH),
            ("btn_compare", COMPARISON_ICON_PATH),
            ("btn_move", MOVE_FOLDER_ICON_PATH),
            ("btn_copy", COPY_FOLDER_ICON_PATH),
            ("btn_delete", DELETE_ICON_PATH),
            ("btn_notify", ALARM_ICON_PATH),
            ("btn_no_folders", NO_FOLDER_ICON_PATH),
        ]:
            if hasattr(self, btn_name):
                btn = getattr(self, btn_name)
                set_icon(btn, icon_path, tint=True)
    except Exception:
        pass
    
    try:
        if hasattr(self, "btn_language") and hasattr(self.btn_language, "setLanguageIcon"):
            lang_icon_path = rsrc_path("icon", "language.png")
            if lang_icon_path and os.path.exists(lang_icon_path):
                self.btn_language.setLanguageIcon(self._themed_icon(lang_icon_path))
    except Exception:
        pass

    try:
        indicator = getattr(self, "selection_mode_indicator", None)
        if indicator is not None:
            icon = self._themed_icon(CHOICE_ICON_PATH)
            if not icon.isNull():
                indicator.setIcon(icon)
    except Exception:
        pass

    self._update_filter_icon_pm()
    self._update_search_icon()
    self._refresh_search_palette()


def _restore_button_icon_from_base(self, btn: QAbstractButton) -> None:
    """Restore button icon from saved base path."""
    if not hasattr(btn, "icon_path"):
        return
    path = btn.property("icon_path")
    if path:
        try:
            btn.setIcon(self._themed_icon(path, tint_allowed=True))
        except Exception:
            pass


def _apply_hover_filter(self, btn: QAbstractButton) -> None:
    """Apply hover filter for black icon tinting in dark theme."""
    dark = getattr(self, "_current_theme", THEME_LIGHT) == THEME_DARK
    if not dark:
        return
    
    class HoverFilter(QObject):
        def __init__(self, button):
            super().__init__(button)
            self.button = button
            self.base_pixmap = None
            try:
                if not button.icon().isNull():
                    self.base_pixmap = button.icon().pixmap(button.iconSize())
            except Exception:
                pass
        
        def eventFilter(self, obj, ev):
            try:
                if ev.type() == ev.Type.Enter:
                    if self.base_pixmap:
                        tinted = _tint_pixmap(self.base_pixmap, QColor("#404040"))
                        self.button.setIcon(QIcon(tinted))
                elif ev.type() == ev.Type.Leave:
                    if self.base_pixmap:
                        self.button.setIcon(QIcon(self.base_pixmap))
            except Exception:
                pass
            return super().eventFilter(obj, ev)
    
    if btn.installEventFilter:
        try:
            filter_obj = HoverFilter(btn)
            # Keep a strong reference to avoid PySide/Qt crash on later events.
            try:
                setattr(btn, "_hover_filter_obj", filter_obj)
            except Exception:
                pass
            btn.installEventFilter(filter_obj)
        except Exception:
            pass


def _install_hover_black_icons(self) -> None:
    """Install hover filters for buttons in dark theme (disabled per user request)."""
    return


def _blur_splitter_handles(self, split: QSplitter):
    """Apply blur effect to splitter handles."""
    try:
        if not hasattr(split, "handle_count"):
            return
        for i in range(split.count()):
            handle = split.handle(i + 1)
            if handle:
                handle.setProperty("transparent", True)
                handle.setStyleSheet("QSplitter::handle { background: transparent; }")
    except Exception:
        pass


def _enhance_splitter_handles(self, split: QSplitter):
    """Enhance splitter handles with subtle gradient."""
    try:
        if not hasattr(split, "handle_count"):
            return
        dark = getattr(self, "_current_theme", THEME_LIGHT) == THEME_DARK
        base_color = "#1A1A1A" if dark else "#E0E0E0"
        for i in range(split.count()):
            handle = split.handle(i + 1)
            if handle:
                handle.setProperty("transparent", False)
                handle.setStyleSheet(f"""
                QSplitter::handle {{
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, 
                        stop:0 {base_color}, stop:0.5 {base_color}, stop:1 {base_color});
                    border: 1px solid {"#2A2A2A" if dark else "#D0D0D0"};
                    width: 1px;
                }}
                QSplitter::handle:hover {{
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, 
                        stop:0 {"#3A3A3A" if dark else "#C0C0C0"}, 
                        stop:0.5 {"#3A3A3A" if dark else "#C0C0C0"}, 
                        stop:1 {"#3A3A3A" if dark else "#C0C0C0"});
                    width: 2px;
                }}
                """)
    except Exception:
        pass


def _tinted_icon(self, path: str, color: 'QtGui.QColor') -> 'QtGui.QIcon':
    """Create icon tinted with specified color."""
    try:
        if not path or not os.path.exists(path):
            return QIcon()
        pixmap = QPixmap(path)
        if pixmap.isNull():
            return QIcon()
        tinted = _tint_pixmap(pixmap, color)
        return QIcon(tinted)
    except Exception:
        return QIcon()


def _on_theme_toggled(self, dark: bool) -> None:
    """Handle theme toggle event."""
    theme = THEME_DARK if dark else THEME_LIGHT
    self._current_theme = theme

    print(f"[THEME] Toggling theme to: {theme} (dark={dark})")

    try:
        if hasattr(self, "theme_toggle"):
            self.theme_toggle.setChecked(dark)
            self.theme_toggle.snap_to_state()
    except Exception:
        pass

    # Save theme to JSON settings
    try:
        from ..utils.theme import save_theme
        save_theme(theme)
    except Exception:
        pass

    # Apply theme stylesheets
    try:
        from ..utils.theme import apply_light_theme, apply_dark_theme
        app = QApplication.instance()
        if app:
            print(f"[THEME] Applying {'dark' if dark else 'light'} theme to QApplication")
            if dark:
                apply_dark_theme(app)
            else:
                apply_light_theme(app)
            print(f"[THEME] Theme applied, stylesheet length: {len(app.styleSheet() or '')}")
        else:
            print(f"[THEME] ERROR: QApplication.instance() is None")
    except Exception as e:
        print(f"[THEME] ERROR applying theme: {e}")
        import traceback
        traceback.print_exc()

    # SortHeader paints the sorting indicator itself, so refresh its tint
    # after the application palette has changed.
    try:
        header = self.table.horizontalHeader()
        if hasattr(header, "set_dark_mode"):
            header.set_dark_mode(dark)
    except (AttributeError, RuntimeError):
        pass

    self._apply_icon_theme(theme)
    try:
        if hasattr(self, "_set_status_shell_theme"):
            self._set_status_shell_theme(dark)
    except Exception:
        pass
    try:
        if hasattr(self, "file_operation_status"):
            self.file_operation_status.set_dark_theme(dark)
    except Exception:
        pass

    try:
        if dark:
            self._install_hover_black_icons()
    except Exception:
        pass

    try:
        from ..utils.helpers import _set_window_theme_dark
        _set_window_theme_dark(self, dark=dark)
    except Exception:
        pass

    QApplication.processEvents()

    # Re-apply deterministic popup styling for projects combobox.
    try:
        if hasattr(self, "_prepare_projects_combo_popup"):
            self._prepare_projects_combo_popup()
    except Exception:
        pass
    pdf_windows = []
    for pdf_window in list(getattr(self, "_pdf_compare_windows", [])):
        try:
            if not pdf_window.isVisible():
                continue
            pdf_window.apply_theme_state(dark, persist=False)
            pdf_windows.append(pdf_window)
        except (RuntimeError, AttributeError):
            pass
    self._pdf_compare_windows = pdf_windows


def _on_language_toggle(self):
    from ..utils.i18n import toggle_language, get_language_manager
    toggle_language()
    self._retranslate_ui()


def _retranslate_ui(self):
    try:
        if hasattr(self, "theme_toggle"):
            self.theme_toggle.setToolTip(t("toolbar.theme_toggle"))
        if hasattr(self, "btn_language"):
            self.btn_language.setToolTip(t("toolbar.language_toggle"))
            if hasattr(self.btn_language, "setLanguageText"):
                self.btn_language.setLanguageText(self._get_language_code())
        if hasattr(self, "btn_notify"):
            self.btn_notify.setToolTip(t("toolbar.notifications"))
        if hasattr(self, "btn_refresh"):
            self.btn_refresh.setToolTip(t("toolbar.refresh"))
        if hasattr(self, "btn_back"):
            self.btn_back.setToolTip(t("toolbar.back"))
        if hasattr(self, "btn_sync_all"):
            self.btn_sync_all.setToolTip(t("toolbar.sync_all"))
        if hasattr(self, "btn_go_to_root"):
            self.btn_go_to_root.setText(t("toolbar.go_to_root"))
        if hasattr(self, "btn_login"):
            self.btn_login.setText(t("toolbar.login"))
        if hasattr(self, "btn_plus"):
            self.btn_plus.setToolTip(t("toolbar.add"))
        if hasattr(self, "btn_download"):
            self.btn_download.setToolTip(t("toolbar.download_checked"))
        if hasattr(self, "btn_rename"):
            self.btn_rename.setToolTip(t("toolbar.rename"))
        if hasattr(self, "btn_compare"):
            self.btn_compare.setToolTip(t("toolbar.compare_versions"))
        if hasattr(self, "btn_move"):
            self.btn_move.setToolTip(t("toolbar.move"))
        if hasattr(self, "btn_copy"):
            self.btn_copy.setToolTip(t("toolbar.copy"))
        if hasattr(self, "btn_delete"):
            self.btn_delete.setToolTip(t("toolbar.delete_checked"))
        if hasattr(self, "btn_columns"):
            self.btn_columns.setToolTip(t("toolbar.column_settings"))
        if hasattr(self, "search"):
            self.search.setPlaceholderText(t("search.placeholder"))
        if hasattr(self, "btn_no_folders"):
            self.btn_no_folders.setToolTip(t("filter.no_folders_tooltip"))
        if hasattr(self, "hdrcb"):
            self.hdrcb.setToolTip(t("table.checkbox_tooltip"))
        if hasattr(self, "tree"):
            self.tree.setHeaderLabels([t("tree.project_files")])
        if hasattr(self, "act_upload_file"):
            self.act_upload_file.setText(t("menu.upload_file"))
        if hasattr(self, "act_create_folder"):
            self.act_create_folder.setText(t("menu.create_folder"))
        if hasattr(self, "act_upload_folder"):
            self.act_upload_folder.setText(t("menu.upload_folder"))
        if hasattr(self, "act_switch_user"):
            self.act_switch_user.setText(t("menu.switch_user"))
        if hasattr(self, "act_select_workspace"):
            self.act_select_workspace.setText(t("menu.select_workspace"))
        if hasattr(self, "lbl_proj"):
            self.lbl_proj.setText(t("common.project") + ":")
        if hasattr(self, "cb_projects"):
            try:
                if self.cb_projects.count() > 0 and self.cb_projects.itemData(0) is None:
                    self.cb_projects.setItemText(0, t("common.select_project"))
            except Exception:
                pass
        if hasattr(self, "files_model"):
            self.files_model._retranslate_headers()
            self.files_model.headerDataChanged.emit(Qt.Horizontal, 0, self.files_model.columnCount() - 1)
            if hasattr(self, "table") and self.table.model():
                rows = self.table.model().rowCount()
                if rows > 0:
                    self.table.model().dataChanged.emit(
                        self.table.model().index(0, 9),
                        self.table.model().index(rows - 1, 9)
                    )
        self.update()
    except Exception:
        pass


def inject_theme_operations(MainWindowClass) -> None:
    MainWindowClass._themed_icon = _themed_icon
    MainWindowClass._themed_standard_icon = _themed_standard_icon
    MainWindowClass._update_filter_icon_pm = _update_filter_icon_pm
    MainWindowClass._update_search_icon = _update_search_icon
    MainWindowClass._refresh_search_palette = _refresh_search_palette
    MainWindowClass._refresh_secondary_style = _refresh_secondary_style
    MainWindowClass._apply_icon_theme = _apply_icon_theme
    MainWindowClass._restore_button_icon_from_base = _restore_button_icon_from_base
    MainWindowClass._apply_hover_filter = _apply_hover_filter
    MainWindowClass._install_hover_black_icons = _install_hover_black_icons
    MainWindowClass._blur_splitter_handles = _blur_splitter_handles
    MainWindowClass._enhance_splitter_handles = _enhance_splitter_handles
    MainWindowClass._tinted_icon = _tinted_icon
    MainWindowClass._on_theme_toggled = _on_theme_toggled
    MainWindowClass._on_language_toggle = _on_language_toggle
    MainWindowClass._retranslate_ui = _retranslate_ui

# Alias for backward compatibility
inject_theme_operations_to_main_window = inject_theme_operations
